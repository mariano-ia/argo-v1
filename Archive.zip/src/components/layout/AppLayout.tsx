
import React from 'react';
import { Scan } from 'lucide-react';

interface LayoutProps {
    children: React.ReactNode;
}

export const AppLayout: React.FC<LayoutProps> = ({ children }) => {
    return (
        <div className="min-h-screen bg-argos-deep text-argos-text font-sans relative overflow-x-hidden selection:bg-argos-cyan selection:text-argos-deep">

            {/* Background ambient effects */}
            <div className="fixed inset-0 pointer-events-none z-0">
                <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] bg-argos-cyan/5 rounded-full blur-[100px]" />
                <div className="absolute bottom-[-20%] left-[-10%] w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[100px]" />
                <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150 mix-blend-overlay"></div>
            </div>

            {/* Content */}
            <div className="relative z-10 max-w-md mx-auto min-h-screen flex flex-col border-x border-white/5 bg-argos-deep/50 backdrop-blur-sm shadow-2xl">

                {/* Header / HUD */}
                <header className="sticky top-0 z-50 bg-argos-deep/90 backdrop-blur-md border-b border-white/10 px-6 py-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded bg-gradient-to-br from-argos-cyan to-blue-600 flex items-center justify-center text-argos-deep shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                            <Scan size={18} strokeWidth={2.5} />
                        </div>
                        <h1 className="font-bold text-lg tracking-tight">ARGOS <span className="font-light text-argos-muted">METHOD</span></h1>
                    </div>
                    <div className="flex gap-1">
                        <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse"></div>
                        <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse delay-75"></div>
                        <div className="w-1 h-1 bg-green-500 rounded-full animate-pulse delay-150"></div>
                    </div>
                </header>

                <main className="flex-1 p-6 flex flex-col gap-8 pb-20">
                    {children}
                </main>

                {/* Footer / Status */}
                <footer className="border-t border-white/5 py-4 px-6 text-center text-xs text-argos-muted/50 uppercase tracking-widest">
                    System Online • v1.0.4 • NAVE ARGOS
                </footer>
            </div>
        </div>
    );
};
