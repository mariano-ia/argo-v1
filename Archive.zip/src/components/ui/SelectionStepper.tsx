
import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Check, ChevronRight } from 'lucide-react';

interface Option {
    id: string;
    label: string;
    value: string;
}

interface StepperProps {
    title: string;
    options: Option[];
    selectedValue: string;
    onSelect: (value: string) => void;
    className?: string;
}

export const SelectionStepper: React.FC<StepperProps> = ({
    title,
    options,
    selectedValue,
    onSelect,
    className
}) => {
    return (
        <div className={cn("flex flex-col gap-4", className)}>
            <h3 className="text-argos-cyan text-sm uppercase tracking-widest font-bold mb-2 flex items-center gap-2">
                <span className="w-2 h-2 bg-argos-cyan rounded-full animate-pulse"></span>
                {title}
            </h3>

            <div className="grid grid-cols-1 gap-3">
                {options.map((option) => {
                    const isSelected = selectedValue === option.value;
                    return (
                        <motion.button
                            key={option.id}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => onSelect(option.value)}
                            className={cn(
                                "relative flex items-center justify-between p-4 rounded-lg border transition-all duration-300 text-left",
                                isSelected
                                    ? "bg-argos-cyan/10 border-argos-cyan text-white shadow-[0_0_15px_rgba(6,182,212,0.2)]"
                                    : "bg-argos-surface/50 border-argos-muted/20 text-argos-muted hover:border-argos-muted/50 hover:bg-argos-surface"
                            )}
                        >
                            <span className="font-semibold tracking-wide">{option.label}</span>

                            {isSelected && (
                                <motion.div
                                    initial={{ opacity: 0, scale: 0.5 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="bg-argos-cyan text-argos-deep rounded-full p-1"
                                >
                                    <Check size={16} strokeWidth={3} />
                                </motion.div>
                            )}

                            {!isSelected && <ChevronRight size={16} className="text-argos-muted/50" />}
                        </motion.button>
                    );
                })}
            </div>
        </div>
    );
};
