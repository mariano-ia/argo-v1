
import React from 'react';
import { cn } from '@/lib/utils';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { BentoBox } from './BentoBox';
import { SintoniaData } from '@/lib/argosEngine';

interface TuningProps {
    data: SintoniaData | null;
}

export const TuningTable: React.FC<TuningProps> = ({ data }) => {
    if (!data) return null;

    return (
        <BentoBox title="Sintonía Fina">
            <div className="flex flex-col gap-4">
                <div className="text-sm font-medium text-argos-cyan mb-2">
                    Situación: <span className="text-white">{data.situacion}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-green-400 mb-2 uppercase text-xs font-bold tracking-wider">
                            <ThumbsUp size={14} /> Hacer
                        </div>
                        <p className="text-sm leading-relaxed">{data.hacer}</p>
                    </div>

                    <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
                        <div className="flex items-center gap-2 text-red-400 mb-2 uppercase text-xs font-bold tracking-wider">
                            <ThumbsDown size={14} /> Evitar
                        </div>
                        <p className="text-sm leading-relaxed">{data.evitar}</p>
                    </div>
                </div>
            </div>
        </BentoBox>
    );
};
