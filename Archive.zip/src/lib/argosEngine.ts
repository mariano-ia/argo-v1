
export type Eje = 'D' | 'I' | 'S' | 'C' | 'C+S'; // Added C+S from archetype mapping
export type Motor = 'Rápido' | 'Medio' | 'Lento';

// Broad type for lookup keys to handle generic/missing strings safely
export type EjeInput = string;
export type MotorInput = string;
export type SintoniaInput = string;

export interface Archetype {
    id: string;
    eje: EjeInput;
    motor: MotorInput;
    label: string;
}

export interface SintoniaData {
    situacion: string;
    hacer: string;
    evitar: string;
}

export interface ReportData {
    bienvenida: string;
    brujula: string;
    ritmo: string;
    arquetipo: Archetype;
    sintonia: SintoniaData | null;
}

// Data Foundation
const ARQUETIPOS: Archetype[] = [
    { id: "tanque", eje: "D", motor: "Lento", label: "Impulsor Persistente" },
    { id: "dinamico", eje: "D", motor: "Rápido", label: "Impulsor Dinámico" },
    { id: "vibrante", eje: "I", motor: "Rápido", label: "Conector Vibrante" },
    { id: "ajedrecista", eje: "C+S", motor: "Lento", label: "Estratega Observador" }
];

const TEXT_BLOCKS = {
    seccion_0_bienvenida: "Este mapa nos permite asomarnos a la manera en que [Nombre] vive y siente el deporte hoy... Nota de evolución: Este informe es una fotografía del presente.",
    seccion_1_brujula_D: "Tendencia hacia la Dominancia. Motivación central: Impacto y Control. Aporte principal: determinación y coraje.",
    // Missing texts for I, S, C will return DATA_MISSING via logic or default
    seccion_2_ritmo_lento: "Tiempo de Procesamiento Deliberado. Prioriza la firmeza y la seguridad sobre la velocidad pura.",
    // Missing texts for Rapido, Medio
};

const SINTONIA_EXAMPLES: Record<string, SintoniaData> = {
    "Mantenga su interés": {
        situacion: "Mantenga su interés",
        hacer: "Roles de lectura o distribución del juego",
        evitar: "Pedirle que mantenga una intensidad física frenética sin propósito"
    }
};

/**
 * Deterministic lookup for text blocks.
 * Returns [DATA_MISSING] if specific key is not found.
 */
function getTextBlock(key: string): string {
    // @ts-ignore
    const val = TEXT_BLOCKS[key];
    return val || "[DATA_MISSING]";
}

/**
 * Reconstructs the 'Argos Method' report product.
 * @param eje - The DISC axis (D, I, S, C)
 * @param motor - The engine speed (Rápido, Medio, Lento)
 * @param sintonia - The tuning situation key (optional/specific)
 * @param nombre - Name for personalization
 */
export function getReportData(
    eje: EjeInput,
    motor: MotorInput,
    sintonia: SintoniaInput,
    nombre: string = "[Nombre]"
): ReportData {

    // 1. Find Archetype
    const arquetipo = ARQUETIPOS.find(
        (a) => a.eje === eje && a.motor === motor
    ) || {
        id: "unknown",
        eje: eje,
        motor: motor,
        label: "[DATA_MISSING]"
    };

    // 2. Resolve Text Blocks
    // Welcoming text with name injection
    let bienvenida = getTextBlock("seccion_0_bienvenida");
    bienvenida = bienvenida.replace("[Nombre]", nombre);

    // Compass/Brújula text (Based on Axis/Eje)
    // Mapping logic: seccion_1_brujula_{EJE}
    const brujulaKey = `seccion_1_brujula_${eje}`;
    const brujula = getTextBlock(brujulaKey);

    // Rhythm/Ritmo text (Based on Engine/Motor)
    // Mapping logic: seccion_2_ritmo_{MOTOR.lower}
    // Data has "seccion_2_ritmo_lento", so we lowercase the input "Lento" -> "lento"
    const motorLower = motor.toLowerCase();
    const ritmoKey = `seccion_2_ritmo_${motorLower}`;
    const ritmo = getTextBlock(ritmoKey);

    // 3. Resolve Tuning/Sintonía
    // If sintonia is provided, look it up.
    const sintoniaData = SINTONIA_EXAMPLES[sintonia] || null;

    return {
        bienvenida,
        brujula,
        ritmo,
        arquetipo,
        sintonia: sintoniaData
            ? sintoniaData
            : {
                situacion: sintonia,
                hacer: "[DATA_MISSING]",
                evitar: "[DATA_MISSING]"
            }
    };
}
