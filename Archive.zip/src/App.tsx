
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AppLayout } from './components/layout/AppLayout';
import { SelectionStepper } from './components/ui/SelectionStepper';
import { BentoBox } from './components/ui/BentoBox';
import { Brujula } from './components/charts/Brujula';
import { TuningTable } from './components/ui/TuningTable';
import { getReportData, EjeInput, MotorInput, SintoniaInput } from './lib/argosEngine';
import { ArrowRight, RotateCcw } from 'lucide-react';

function App() {
    const [step, setStep] = useState<'inputs' | 'report'>('inputs');
    const [eje, setEje] = useState<EjeInput>('D');
    const [motor, setMotor] = useState<MotorInput>('Lento');
    const [sintonia, setSintonia] = useState<SintoniaInput>('Mantenga su interés');

    const report = getReportData(eje, motor, sintonia, "Usuario");

    // Chart data mapping based on Eje
    const getChartData = (axis: string) => {
        // Deterministic simulation for the chart based on the primary axis
        const base = 30;
        const peak = 90;
        return [
            { subject: 'D', A: axis.includes('D') ? peak : base, fullMark: 100 },
            { subject: 'I', A: axis.includes('I') ? peak : base, fullMark: 100 },
            { subject: 'S', A: axis.includes('S') ? peak : base, fullMark: 100 },
            { subject: 'C', A: axis.includes('C') ? peak : base, fullMark: 100 },
        ];
    };

    return (
        <AppLayout>
            <AnimatePresence mode="wait">
                {step === 'inputs' ? (
                    <motion.div
                        key="inputs"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="flex flex-col gap-8"
                    >
                        <div className="space-y-2">
                            <h2 className="text-2xl font-bold bg-gradient-to-r from-white to-argos-muted bg-clip-text text-transparent">
                                Calibración de Sensores
                            </h2>
                            <p className="text-argos-muted text-sm border-l-2 border-argos-cyan pl-3">
                                Configure los parámetros de entrada para generar la proyección holográfica.
                            </p>
                        </div>

                        <SelectionStepper
                            title="Eje Dominante (DISC)"
                            selectedValue={eje}
                            onSelect={setEje}
                            options={[
                                { id: 'd', label: 'Impulsor (D)', value: 'D' },
                                { id: 'i', label: 'Conector (I)', value: 'I' },
                                { id: 's', label: 'Sostén (S)', value: 'S' },
                                { id: 'c', label: 'Estratega (C)', value: 'C' },
                                { id: 'cs', label: 'Estratega (C+S)', value: 'C+S' },
                            ]}
                        />

                        <SelectionStepper
                            title="Motor (Ritmo)"
                            selectedValue={motor}
                            onSelect={setMotor}
                            options={[
                                { id: 'rapido', label: 'Rápido', value: 'Rápido' },
                                { id: 'medio', label: 'Medio', value: 'Medio' },
                                { id: 'lento', label: 'Lento', value: 'Lento' },
                            ]}
                        />

                        <SelectionStepper
                            title="Sintonía (Situación)"
                            selectedValue={sintonia}
                            onSelect={setSintonia}
                            options={[
                                { id: 'interes', label: 'Mantenga su interés', value: 'Mantenga su interés' },
                                { id: 'stress', label: 'Bajo Presión (Demo)', value: 'Bajo Presión' },
                            ]}
                        />

                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setStep('report')}
                            className="w-full bg-gradient-to-r from-argos-cyan to-blue-600 text-white font-bold py-4 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center justify-center gap-2 mt-4"
                        >
                            INICIAR ANÁLISIS <ArrowRight size={20} />
                        </motion.button>

                    </motion.div>
                ) : (
                    <motion.div
                        key="report"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="flex flex-col gap-6"
                    >
                        {/* Header Reporte */}
                        <div className="flex items-start justify-between">
                            <div>
                                <div className="text-xs uppercase tracking-widest text-argos-cyan mb-1">Identidad Detectada</div>
                                <h2 className="text-3xl font-bold text-white leading-tight">{report.arquetipo.label}</h2>
                            </div>
                            <div className="px-3 py-1 bg-white/10 rounded text-xs font-mono text-argos-muted">
                                ID: {report.arquetipo.id.toUpperCase()}
                            </div>
                        </div>

                        {/* Bienvenida */}
                        <BentoBox className="border-l-4 border-l-argos-cyan">
                            <p className="text-lg italic leading-relaxed text-argos-text/90">"{report.bienvenida}"</p>
                        </BentoBox>

                        {/* Brújula */}
                        <BentoBox title="La Brújula" className="h-[400px]">
                            <Brujula axesData={getChartData(eje)} />
                            <div className="mt-4 text-sm text-center text-argos-muted/80 px-4">
                                {report.brujula}
                            </div>
                        </BentoBox>

                        {/* Ritmo */}
                        <BentoBox title="Motor & Ritmo">
                            <div className="flex items-center gap-4 mb-3">
                                <div className="w-12 h-12 rounded-full border-2 border-argos-ember flex items-center justify-center text-argos-ember font-bold">
                                    {motor[0]}
                                </div>
                                <div className="text-xl font-bold">{motor}</div>
                            </div>
                            <p className="text-sm leading-relaxed text-argos-muted">{report.ritmo}</p>
                        </BentoBox>

                        {/* Sintonía */}
                        <TuningTable data={report.sintonia} />

                        {/* Reset Action */}
                        <button
                            onClick={() => setStep('inputs')}
                            className="mx-auto flex items-center gap-2 text-argos-muted hover:text-white transition-colors py-4 text-sm uppercase tracking-wider"
                        >
                            <RotateCcw size={16} /> Reiniciar Sistema
                        </button>

                    </motion.div>
                )}
            </AnimatePresence>
        </AppLayout>
    );
}

export default App;
