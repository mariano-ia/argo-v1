/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                argos: {
                    deep: '#0f172a',    // Deep Ocean Blue
                    surface: '#1e293b', // Lighter Blue/Grey
                    cyan: '#06b6d4',    // Holographic Cyan
                    ember: '#f59e0b',   // Alert Amber
                    text: '#f8fafc',    // Off-white text
                    muted: '#94a3b8',   // Muted text
                }
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            },
            animation: {
                'scan': 'scan 4s linear infinite',
            },
            keyframes: {
                scan: {
                    '0%': { transform: 'translateY(0)' },
                    '100%': { transform: 'translateY(100%)' },
                }
            }
        },
    },
    plugins: [],
}
